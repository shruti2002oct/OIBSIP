package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

public class QuizActivity extends AppCompatActivity {

    private TextView tvQuestion,tvScore,tvQuestionNo,textDisplayScore;
    private RadioGroup radioGroup;
    private RadioButton rb1,rb2,rb3,rb4;
    private Button btnNext;
    int totalQue;
    int count=0;
    ColorStateList dfRbColor;
    boolean answered;
    int score;
    private QuestionModel currentQue;
    private List<QuestionModel> questionsList;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        questionsList = new ArrayList<>();
        tvQuestion = findViewById(R.id.textQuestion);
        tvScore = findViewById(R.id.textScore);
        tvQuestionNo = findViewById(R.id.textQuestionNo);
        radioGroup = findViewById(R.id.radioGroup);
        rb1 = findViewById(R.id.rb1);
        rb2 = findViewById(R.id.rb2);
        rb3 = findViewById(R.id.rb3);
        rb4 = findViewById(R.id.rb4);
        btnNext = findViewById(R.id.btnNext);
        textDisplayScore = findViewById(R.id.textDisplayScore);
        dfRbColor = rb1.getTextColors();

        addQuestions();
        totalQue = questionsList.size();
        showNextQuestion();

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (answered == false){
                    if (rb1.isChecked() || rb2.isChecked() || rb3.isChecked() || rb4.isChecked()){
                        checkAnswer();
                    }
                    else {
                        Toast.makeText(QuizActivity.this,"Please select an option",Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    showNextQuestion();
                }
            }
        });
    }

    private void checkAnswer() {
        answered = true;
        RadioButton rbSelected = findViewById(radioGroup.getCheckedRadioButtonId());
        int ansNo = radioGroup.indexOfChild(rbSelected) + 1;
        if (ansNo == currentQue.getCorrectAnsNo()){
            score++;
            tvScore.setText("Score: "+score);
        }
        rb1.setTextColor(Color.RED);
        rb2.setTextColor(Color.RED);
        rb3.setTextColor(Color.RED);
        rb4.setTextColor(Color.RED);
        switch (currentQue.getCorrectAnsNo()){
            case 1:
                rb1.setTextColor(Color.GREEN);
                break;
            case 2:
                rb2.setTextColor(Color.GREEN);
                break;
            case 3:
                rb3.setTextColor(Color.GREEN);
                break;
            case 4:
                rb4.setTextColor(Color.GREEN);
                break;
        }
        if (count < totalQue){
            btnNext.setText("Next");
        }
        else {
            btnNext.setText("Finish");
        }
        if (count == totalQue){
            textDisplayScore.setText("Your score is : "+score);
        }
    }

    private void showNextQuestion() {
        radioGroup.clearCheck();
        rb1.setTextColor(dfRbColor);
        rb2.setTextColor(dfRbColor);
        rb3.setTextColor(dfRbColor);
        rb4.setTextColor(dfRbColor);

        if (count < totalQue){
            currentQue = questionsList.get(count);
            tvQuestion.setText(currentQue.getQue());
            rb1.setText(currentQue.getOp1());
            rb2.setText(currentQue.getOp2());
            rb3.setText(currentQue.getOp3());
            rb4.setText(currentQue.getOp4());
            count++;

            btnNext.setText("Submit");
            tvQuestionNo.setText("Questions: "+count+"/"+totalQue);
            answered = false;
        }
        else {
            finish();
        }
    }


    private void addQuestions() {
        questionsList.add(new QuestionModel("Which of the following is not a programming language?"," HTML"," CSS","JavaScript","XML",4));
        questionsList.add(new QuestionModel("Which of the following data types is used to store whole numbers in programming?","  float"," double","int","char",3));
        questionsList.add(new QuestionModel("Which of the following operators is used to compare two values in programming?","  +","-","*","==",4));
        questionsList.add(new QuestionModel("Which of the following is not an object-oriented programming language?","Java","Python","C++","Fortran",4));
        questionsList.add(new QuestionModel("Which of the following is a popular integrated development environment (IDE) for Java?","Eclipse","Visual Studio Code","Atom","Sublime Text",1));

    }
}